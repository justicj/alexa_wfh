'use strict';
var Alexa = require('alexa-sdk');
var APP_ID = undefined;  // TODO replace with your app ID (OPTIONAL).

var languageStrings = {
    "en": {
        "translation": {
            "EXCUSES": [
                "Doctors appointment.",
                "Sick Kid.",
                "Food Poisoning.",
                "Dentist appointment.",
                "Just spent the past couple of hours in the bathroom, don't ask.",
                "I'm having furniture delivered to my house.",
                "I have to sign for a package.",
                "A pipe burst this morning, waiting on a plumber.",
            ],
            "SKILL_NAME" : "Work From Home Excuses",
            "GET_EXCUSE_MESSAGE" : "Here's your Excuse: ",
            "HELP_MESSAGE" : "You can say, give me a Excuse, or, you can say exit... What can I help you with?",
            "HELP_REPROMPT" : "What can I help you with?",
            "STOP_MESSAGE" : "Goodbye!"
        }
    },
    "en-US": {
        "translation": {
          "EXCUSES": [
              "Doctors appointment.",
              "Sick Kid.",
              "Food Poisoning.",
              "Dentist appointment.",
              "Just spent the past couple of hours in the bathroom, don't ask.",
              "I'm having furniture delivered to my house.",
              "I have to sign for a package.",
              "A pipe burst this morning, waiting on a plumber.",
          ],
            "SKILL_NAME" : "American Work From Home EXCUSES"
        }
    },
    "en-GB": {
        "translation": {
          "EXCUSES": [
              "Doctors appointment.",
              "Sick Kid.",
              "Food Poisoning.",
              "Dentist appointment.",
              "Just spent the past couple of hours in the bathroom, don't ask.",
              "I'm having furniture delivered to my house.",
              "I have to sign for a package.",
              "A pipe burst this morning, waiting on a plumber.",
          ],
            "SKILL_NAME" : "British Work From Home EXCUSES"
        }
    },
};

exports.handler = function(event, context, callback) {
    var alexa = Alexa.handler(event, context);
    alexa.APP_ID = APP_ID;
    // To enable string internationalization (i18n) features, set a resources object.
    alexa.resources = languageStrings;
    alexa.registerHandlers(handlers);
    alexa.execute();
};

var handlers = {
    'LaunchRequest': function () {
        this.emit('GetExcuse');
    },
    'Unhandled': function() {
        this.emit(':ask', 'WFH did not understand that');
    },
    'GetNewExcuseIntent': function () {
        this.emit('GetExcuse');
    },
    'GetExcuse': function () {
        // Get a random EXCUSE from the EXCUSES list
        // Use this.t() to get corresponding language data
        var ExcuseArr = this.t('EXCUSES');
        var ExcuseIndex = Math.floor(Math.random() * ExcuseArr.length);
        var randomExcuse = ExcuseArr[ExcuseIndex];

        // Create speech output
        var speechOutput = this.t("GET_EXCUSE_MESSAGE") + randomExcuse;
        this.emit(':tellWithCard', speechOutput, this.t("SKILL_NAME"), randomExcuse)
    },
    'AMAZON.HelpIntent': function () {
        var speechOutput = this.t("HELP_MESSAGE");
        var reprompt = this.t("HELP_MESSAGE");
        this.emit(':ask', speechOutput, reprompt);
    },
    'AMAZON.CancelIntent': function () {
        this.emit(':tell', this.t("STOP_MESSAGE"));
    },
    'AMAZON.StopIntent': function () {
        this.emit(':tell', this.t("STOP_MESSAGE"));
    }
};
